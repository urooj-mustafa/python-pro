
1. This GUI Application main Aim is to showing the python Tkinter GUI module
   uses,that how GUI code is working ,how a Frame/Label/Entry/Color......etc is working

2. This Simple Python Tkinter Module project "Shop Management System" Contain verious feature:- 
	a.) first enter customer details
	b.) after that select item which one you want to buy and enter the quantity
	c.) then click on "Total" button now you can see in bottom left of this application
	    there calculation of total product price with GST tax
	d.) after that click on "Bill Generate" button. now you can see the bill of your
	    product in center right feild and save this bill
	e.) You can send this Bill via Email for that go "send bill via Email" section 
	    top right  and Enter your Email and send it (make sure internet connection
	    sould on)
	    (Pc:-For email sending feature first create one dummy Email after that
		go to google with this email and search "Less secure app" after that
		"Turn On" the button for dummy Email .after that enter your email and password
		  in the code section function "Send Email".now you and your email is able send bill. )
	
	f.) Clear :- this button will help to clear all the data which is enter in the Application.

	g.) Search bill section:- in this section you can search your bill data using bill number
			  	  after enter bill number click on "search" button and if that bill
				  is exist then it will show in "bill area section" other it show error on 
				  display and again enter correct bill number.
	h.) Admin Area:- this bottom layout section is for admin/owner for updating shop details/stock etc
	
			 enter the 
					ID ="crpshop123"
					password="123456789"
		
			 Login this
			 after that it will create new window for Admin
			(On admin area am not completly worked on backend Only Aim is to work on GUI module)
	
	i.) Exit :- Exit from the Application
	